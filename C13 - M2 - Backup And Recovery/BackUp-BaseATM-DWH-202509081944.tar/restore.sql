--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "DWH";
--
-- Name: DWH; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "DWH" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_El Salvador.1252';


ALTER DATABASE "DWH" OWNER TO postgres;

\connect "DWH"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Snowflake; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "Snowflake";


ALTER SCHEMA "Snowflake" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dim_departamentos; Type: TABLE; Schema: Snowflake; Owner: postgres
--

CREATE TABLE "Snowflake".dim_departamentos (
    codigo_iso character varying(50) NOT NULL,
    departamento character varying(50),
    capital character varying(50)
);


ALTER TABLE "Snowflake".dim_departamentos OWNER TO postgres;

--
-- Name: dim_mensajes; Type: TABLE; Schema: Snowflake; Owner: postgres
--

CREATE TABLE "Snowflake".dim_mensajes (
    mensaje integer,
    descripcion character varying(50)
);


ALTER TABLE "Snowflake".dim_mensajes OWNER TO postgres;

--
-- Name: dim_respuestas; Type: TABLE; Schema: Snowflake; Owner: postgres
--

CREATE TABLE "Snowflake".dim_respuestas (
    respuesta integer,
    descripcion character varying(50)
);


ALTER TABLE "Snowflake".dim_respuestas OWNER TO postgres;

--
-- Name: dim_terminales; Type: TABLE; Schema: Snowflake; Owner: postgres
--

CREATE TABLE "Snowflake".dim_terminales (
    terminal character varying(50),
    tipo character varying(50),
    nombre character varying(50),
    departamento character varying(50),
    ubicacion character varying(50),
    direccion character varying(50)
);


ALTER TABLE "Snowflake".dim_terminales OWNER TO postgres;

--
-- Name: dim_tipostrasaccion; Type: TABLE; Schema: Snowflake; Owner: postgres
--

CREATE TABLE "Snowflake".dim_tipostrasaccion (
    idtrx integer,
    descripcion character varying(50)
);


ALTER TABLE "Snowflake".dim_tipostrasaccion OWNER TO postgres;

--
-- Name: dim_tipotarjeta; Type: TABLE; Schema: Snowflake; Owner: postgres
--

CREATE TABLE "Snowflake".dim_tipotarjeta (
    bin character varying(6) NOT NULL,
    banco character varying(50),
    tipo character varying(50),
    clasificacion character varying(50)
);


ALTER TABLE "Snowflake".dim_tipotarjeta OWNER TO postgres;

--
-- Name: fact_transaccionesatm; Type: TABLE; Schema: Snowflake; Owner: postgres
--

CREATE TABLE "Snowflake".fact_transaccionesatm (
    id integer NOT NULL,
    dia integer,
    mes integer,
    agno integer,
    terminal character varying(50),
    monto integer,
    respuesta integer,
    mensaje integer,
    trx integer,
    tarjeta character varying(16),
    bin character varying(6)
);


ALTER TABLE "Snowflake".fact_transaccionesatm OWNER TO postgres;

--
-- Name: fact_transaccionesatm_id_seq; Type: SEQUENCE; Schema: Snowflake; Owner: postgres
--

CREATE SEQUENCE "Snowflake".fact_transaccionesatm_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "Snowflake".fact_transaccionesatm_id_seq OWNER TO postgres;

--
-- Name: fact_transaccionesatm_id_seq; Type: SEQUENCE OWNED BY; Schema: Snowflake; Owner: postgres
--

ALTER SEQUENCE "Snowflake".fact_transaccionesatm_id_seq OWNED BY "Snowflake".fact_transaccionesatm.id;


--
-- Name: fact_transaccionesatm id; Type: DEFAULT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".fact_transaccionesatm ALTER COLUMN id SET DEFAULT nextval('"Snowflake".fact_transaccionesatm_id_seq'::regclass);


--
-- Data for Name: dim_departamentos; Type: TABLE DATA; Schema: Snowflake; Owner: postgres
--

COPY "Snowflake".dim_departamentos (codigo_iso, departamento, capital) FROM stdin;
\.
COPY "Snowflake".dim_departamentos (codigo_iso, departamento, capital) FROM '$$PATH$$/4956.dat';

--
-- Data for Name: dim_mensajes; Type: TABLE DATA; Schema: Snowflake; Owner: postgres
--

COPY "Snowflake".dim_mensajes (mensaje, descripcion) FROM stdin;
\.
COPY "Snowflake".dim_mensajes (mensaje, descripcion) FROM '$$PATH$$/4959.dat';

--
-- Data for Name: dim_respuestas; Type: TABLE DATA; Schema: Snowflake; Owner: postgres
--

COPY "Snowflake".dim_respuestas (respuesta, descripcion) FROM stdin;
\.
COPY "Snowflake".dim_respuestas (respuesta, descripcion) FROM '$$PATH$$/4958.dat';

--
-- Data for Name: dim_terminales; Type: TABLE DATA; Schema: Snowflake; Owner: postgres
--

COPY "Snowflake".dim_terminales (terminal, tipo, nombre, departamento, ubicacion, direccion) FROM stdin;
\.
COPY "Snowflake".dim_terminales (terminal, tipo, nombre, departamento, ubicacion, direccion) FROM '$$PATH$$/4957.dat';

--
-- Data for Name: dim_tipostrasaccion; Type: TABLE DATA; Schema: Snowflake; Owner: postgres
--

COPY "Snowflake".dim_tipostrasaccion (idtrx, descripcion) FROM stdin;
\.
COPY "Snowflake".dim_tipostrasaccion (idtrx, descripcion) FROM '$$PATH$$/4960.dat';

--
-- Data for Name: dim_tipotarjeta; Type: TABLE DATA; Schema: Snowflake; Owner: postgres
--

COPY "Snowflake".dim_tipotarjeta (bin, banco, tipo, clasificacion) FROM stdin;
\.
COPY "Snowflake".dim_tipotarjeta (bin, banco, tipo, clasificacion) FROM '$$PATH$$/4955.dat';

--
-- Data for Name: fact_transaccionesatm; Type: TABLE DATA; Schema: Snowflake; Owner: postgres
--

COPY "Snowflake".fact_transaccionesatm (id, dia, mes, agno, terminal, monto, respuesta, mensaje, trx, tarjeta, bin) FROM stdin;
\.
COPY "Snowflake".fact_transaccionesatm (id, dia, mes, agno, terminal, monto, respuesta, mensaje, trx, tarjeta, bin) FROM '$$PATH$$/4962.dat';

--
-- Name: fact_transaccionesatm_id_seq; Type: SEQUENCE SET; Schema: Snowflake; Owner: postgres
--

SELECT pg_catalog.setval('"Snowflake".fact_transaccionesatm_id_seq', 11000, true);


--
-- Name: dim_departamentos dim_departamentos_pk; Type: CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".dim_departamentos
    ADD CONSTRAINT dim_departamentos_pk PRIMARY KEY (codigo_iso);


--
-- Name: dim_mensajes dim_mensajes_unique; Type: CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".dim_mensajes
    ADD CONSTRAINT dim_mensajes_unique UNIQUE (mensaje);


--
-- Name: dim_respuestas dim_respuestas_unique; Type: CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".dim_respuestas
    ADD CONSTRAINT dim_respuestas_unique UNIQUE (respuesta);


--
-- Name: dim_terminales dim_terminales_unique; Type: CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".dim_terminales
    ADD CONSTRAINT dim_terminales_unique UNIQUE (terminal);


--
-- Name: dim_tipostrasaccion dim_tipostrasaccion_unique; Type: CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".dim_tipostrasaccion
    ADD CONSTRAINT dim_tipostrasaccion_unique UNIQUE (idtrx);


--
-- Name: dim_tipotarjeta dim_tipotarjeta_pk; Type: CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".dim_tipotarjeta
    ADD CONSTRAINT dim_tipotarjeta_pk PRIMARY KEY (bin);


--
-- Name: fact_transaccionesatm fact_transaccionesatm_pkey; Type: CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".fact_transaccionesatm
    ADD CONSTRAINT fact_transaccionesatm_pkey PRIMARY KEY (id);


--
-- Name: dim_terminales dim_terminales_dim_departamentos_fk; Type: FK CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".dim_terminales
    ADD CONSTRAINT dim_terminales_dim_departamentos_fk FOREIGN KEY (departamento) REFERENCES "Snowflake".dim_departamentos(codigo_iso);


--
-- Name: fact_transaccionesatm fact_transaccionesatm_dim_mensajes_fk; Type: FK CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".fact_transaccionesatm
    ADD CONSTRAINT fact_transaccionesatm_dim_mensajes_fk FOREIGN KEY (mensaje) REFERENCES "Snowflake".dim_mensajes(mensaje);


--
-- Name: fact_transaccionesatm fact_transaccionesatm_dim_respuestas_fk; Type: FK CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".fact_transaccionesatm
    ADD CONSTRAINT fact_transaccionesatm_dim_respuestas_fk FOREIGN KEY (respuesta) REFERENCES "Snowflake".dim_respuestas(respuesta);


--
-- Name: fact_transaccionesatm fact_transaccionesatm_dim_terminales_fk; Type: FK CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".fact_transaccionesatm
    ADD CONSTRAINT fact_transaccionesatm_dim_terminales_fk FOREIGN KEY (terminal) REFERENCES "Snowflake".dim_terminales(terminal);


--
-- Name: fact_transaccionesatm fact_transaccionesatm_dim_tipostrasaccion_fk; Type: FK CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".fact_transaccionesatm
    ADD CONSTRAINT fact_transaccionesatm_dim_tipostrasaccion_fk FOREIGN KEY (trx) REFERENCES "Snowflake".dim_tipostrasaccion(idtrx);


--
-- Name: fact_transaccionesatm fact_transaccionesatm_dim_tipotarjeta_fk; Type: FK CONSTRAINT; Schema: Snowflake; Owner: postgres
--

ALTER TABLE ONLY "Snowflake".fact_transaccionesatm
    ADD CONSTRAINT fact_transaccionesatm_dim_tipotarjeta_fk FOREIGN KEY (bin) REFERENCES "Snowflake".dim_tipotarjeta(bin) NOT VALID;


--
-- PostgreSQL database dump complete
--

