--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "DWH";
--
-- Name: DWH; Type: DATABASE; Schema: -; Owner: ced
--

CREATE DATABASE "DWH" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "DWH" OWNER TO ced;

\unrestrict (null)
\connect "DWH"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ODM; Type: SCHEMA; Schema: -; Owner: ced
--

CREATE SCHEMA "ODM";


ALTER SCHEMA "ODM" OWNER TO ced;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mdg_country; Type: TABLE; Schema: ODM; Owner: ced
--

CREATE TABLE "ODM".mdg_country (
    "Country Code" character varying(50),
    "Short Name" character varying(100),
    "Table Name" character varying(100),
    "Long Name" character varying(128),
    "2-alpha code" character varying(50),
    "Currency Unit" character varying(100),
    "Special Notes" text,
    "Region" text,
    "Income Group" text,
    "WB-2 code" text,
    "National accounts base year" text,
    "National accounts reference year" text,
    "SNA price valuation" text,
    "Lending category" text,
    "Other groups" text,
    "System of National Accounts" character varying(64),
    "Alternative conversion factor" text,
    "PPP survey year" text,
    "Balance of Payments Manual in use" text,
    "External debt Reporting status" text,
    "System of trade" text,
    "Government Accounting concept" text,
    "IMF data dissemination standard" text,
    "Latest population census" text,
    "Latest household survey" character varying(128),
    "Source of most recent Income and expenditure data" character varying(128),
    "Vital registration complete" text,
    "Latest agricultural census" text,
    "Latest industrial data" integer,
    "Latest trade data" integer,
    "Latest water withdrawal data" integer
);


ALTER TABLE "ODM".mdg_country OWNER TO ced;

--
-- Name: mdg_country_series; Type: TABLE; Schema: ODM; Owner: ced
--

CREATE TABLE "ODM".mdg_country_series (
    "CountryCode" character varying(50),
    "SeriesCode" character varying(50),
    "DESCRIPTION" text
);


ALTER TABLE "ODM".mdg_country_series OWNER TO ced;

--
-- Name: mdg_data; Type: TABLE; Schema: ODM; Owner: ced
--

CREATE TABLE "ODM".mdg_data (
    "Country Name" character varying(100),
    "Country Code" character varying(50),
    "Indicator Name" character varying(1000),
    "Indicator Code" character varying(200),
    "1990" real,
    "1991" real,
    "1992" real,
    "1993" real,
    "1994" real,
    "1995" real,
    "1996" real,
    "1997" real,
    "1998" real,
    "1999" real,
    "2000" real,
    "2001" real,
    "2002" real,
    "2003" real,
    "2004" real,
    "2005" real,
    "2006" real,
    "2007" real,
    "2008" real,
    "2009" real,
    "2010" real,
    "2011" real,
    "2012" real,
    "2013" real,
    "2014" real,
    "2015" real,
    "2016" real
);


ALTER TABLE "ODM".mdg_data OWNER TO ced;

--
-- Name: mdg_footnote; Type: TABLE; Schema: ODM; Owner: ced
--

CREATE TABLE "ODM".mdg_footnote (
    "CountryCode" character varying(50),
    "SeriesCode" character varying(50),
    "Year" character varying(50),
    "DESCRIPTION" text
);


ALTER TABLE "ODM".mdg_footnote OWNER TO ced;

--
-- Name: mdg_series; Type: TABLE; Schema: ODM; Owner: ced
--

CREATE TABLE "ODM".mdg_series (
    "Series Code" character varying(50),
    "Topic" text,
    "Indicator Name" text,
    "Short definition" text,
    "Long definition" text,
    "Unit of measure" text,
    "Periodicity" text,
    "Base Period" integer,
    "Other notes" text,
    "Aggregation method" text,
    "Limitations and exceptions" text,
    "Notes from original source" text,
    "General comments" text,
    "Source" text,
    "Statistical concept and methodology" text,
    "Development relevance" text,
    "Related source links" text,
    "Other web links" text,
    "Related indicators" text,
    "License Type" text
);


ALTER TABLE "ODM".mdg_series OWNER TO ced;

--
-- Name: mdg_series_time; Type: TABLE; Schema: ODM; Owner: ced
--

CREATE TABLE "ODM".mdg_series_time (
    "SeriesCode" character varying(50),
    "Year" character varying(50),
    "DESCRIPTION" character varying(64)
);


ALTER TABLE "ODM".mdg_series_time OWNER TO ced;

--
-- Data for Name: mdg_country; Type: TABLE DATA; Schema: ODM; Owner: ced
--

COPY "ODM".mdg_country ("Country Code", "Short Name", "Table Name", "Long Name", "2-alpha code", "Currency Unit", "Special Notes", "Region", "Income Group", "WB-2 code", "National accounts base year", "National accounts reference year", "SNA price valuation", "Lending category", "Other groups", "System of National Accounts", "Alternative conversion factor", "PPP survey year", "Balance of Payments Manual in use", "External debt Reporting status", "System of trade", "Government Accounting concept", "IMF data dissemination standard", "Latest population census", "Latest household survey", "Source of most recent Income and expenditure data", "Vital registration complete", "Latest agricultural census", "Latest industrial data", "Latest trade data", "Latest water withdrawal data") FROM stdin;
\.
COPY "ODM".mdg_country ("Country Code", "Short Name", "Table Name", "Long Name", "2-alpha code", "Currency Unit", "Special Notes", "Region", "Income Group", "WB-2 code", "National accounts base year", "National accounts reference year", "SNA price valuation", "Lending category", "Other groups", "System of National Accounts", "Alternative conversion factor", "PPP survey year", "Balance of Payments Manual in use", "External debt Reporting status", "System of trade", "Government Accounting concept", "IMF data dissemination standard", "Latest population census", "Latest household survey", "Source of most recent Income and expenditure data", "Vital registration complete", "Latest agricultural census", "Latest industrial data", "Latest trade data", "Latest water withdrawal data") FROM '$$PATH$$/3451.dat';

--
-- Data for Name: mdg_country_series; Type: TABLE DATA; Schema: ODM; Owner: ced
--

COPY "ODM".mdg_country_series ("CountryCode", "SeriesCode", "DESCRIPTION") FROM stdin;
\.
COPY "ODM".mdg_country_series ("CountryCode", "SeriesCode", "DESCRIPTION") FROM '$$PATH$$/3453.dat';

--
-- Data for Name: mdg_data; Type: TABLE DATA; Schema: ODM; Owner: ced
--

COPY "ODM".mdg_data ("Country Name", "Country Code", "Indicator Name", "Indicator Code", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016") FROM stdin;
\.
COPY "ODM".mdg_data ("Country Name", "Country Code", "Indicator Name", "Indicator Code", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016") FROM '$$PATH$$/3450.dat';

--
-- Data for Name: mdg_footnote; Type: TABLE DATA; Schema: ODM; Owner: ced
--

COPY "ODM".mdg_footnote ("CountryCode", "SeriesCode", "Year", "DESCRIPTION") FROM stdin;
\.
COPY "ODM".mdg_footnote ("CountryCode", "SeriesCode", "Year", "DESCRIPTION") FROM '$$PATH$$/3455.dat';

--
-- Data for Name: mdg_series; Type: TABLE DATA; Schema: ODM; Owner: ced
--

COPY "ODM".mdg_series ("Series Code", "Topic", "Indicator Name", "Short definition", "Long definition", "Unit of measure", "Periodicity", "Base Period", "Other notes", "Aggregation method", "Limitations and exceptions", "Notes from original source", "General comments", "Source", "Statistical concept and methodology", "Development relevance", "Related source links", "Other web links", "Related indicators", "License Type") FROM stdin;
\.
COPY "ODM".mdg_series ("Series Code", "Topic", "Indicator Name", "Short definition", "Long definition", "Unit of measure", "Periodicity", "Base Period", "Other notes", "Aggregation method", "Limitations and exceptions", "Notes from original source", "General comments", "Source", "Statistical concept and methodology", "Development relevance", "Related source links", "Other web links", "Related indicators", "License Type") FROM '$$PATH$$/3452.dat';

--
-- Data for Name: mdg_series_time; Type: TABLE DATA; Schema: ODM; Owner: ced
--

COPY "ODM".mdg_series_time ("SeriesCode", "Year", "DESCRIPTION") FROM stdin;
\.
COPY "ODM".mdg_series_time ("SeriesCode", "Year", "DESCRIPTION") FROM '$$PATH$$/3454.dat';

--
-- PostgreSQL database dump complete
--

